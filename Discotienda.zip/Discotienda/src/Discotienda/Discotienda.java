package Discotienda;

import java.io.Serializable;
import java.io.IOException;
import java.util.ArrayList;
import java.io.FileNotFoundException;
import java.io.InvalidClassException;
import java.io.*;

public class Discotienda implements Serializable{
	
	private ArrayList<Disco> discos;
	
	public ArrayList<Disco> getDiscos() {
		return discos;
	}

	public void setDiscos(ArrayList<Disco> discos) {
		this.discos = discos;
	}

	
	public Discotienda() {
		discos = new ArrayList<Disco>();
	}
	
	
	public Discotienda(ArrayList<Disco> discos) {
		super();
		this.discos = discos;
	}

	public void agregarDisco(String nombre, String artista, int anio) {
		Disco nuevo = new Disco(nombre, artista, anio);
		discos.add(nuevo);
	}
	
	public void agregarCancion(String nombreDisco, Cancion cancion) {
		for (Disco disco: discos) {
			if (disco.getNombre().equals(nombreDisco)) {
				disco.getCanciones().add(cancion);
				return;
			}
		}
	}
	
	public void ordenarPorAnio() {
		for (int i = discos.size(); i > 0; i--) {
            for (int j = 0; j < i - 1; j++) {
                Disco d1 = discos.get(j);
                Disco d2 = discos.get(j + 1);

                if (d1.getAnio() < d2.getAnio()) {
                    discos.set(j, d2);
                    discos.set(j + 1, d1);
                }
            }
        }
		
	}
	
	public void imprimirDiscos() {
		for (Disco disco: discos) {
			System.out.println(disco);
			for (Cancion cancion: disco.getCanciones()) {
				System.out.println(" " + cancion);
			}
		}
	}
	
	public static void main(String[] args) {
		Discotienda discotienda = new Discotienda();
		discotienda.agregarDisco("Corazón", "Fonseca", 2005);
		discotienda.agregarCancion("Corazón", new Cancion("Te mando flores", 3, 48, "Musica tropical"));
		discotienda.agregarCancion("Corazón", new Cancion("Hace tiempo", 3, 37, "Musica tropical"));
		Persistencia manejador = new Persistencia(discotienda);
		try {
			manejador.persistirDiscotienda();
		} catch ( IOException e) {
			System.err.println("Error persistiendo la información de la discotienda: " + e.getMessage());
			e.printStackTrace();
		}
		try {
			manejador.cargarDiscotienda();
		} catch (IOException | ClassNotFoundException e) {
			System.err.println("Error cargando la información de la discotienda: " + e.getMessage());
			e.printStackTrace();
		}
		discotienda.imprimirDiscos();
	}
	
}
