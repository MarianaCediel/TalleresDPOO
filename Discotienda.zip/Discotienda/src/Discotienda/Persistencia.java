package Discotienda;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.io.*;

public class Persistencia {
	
	private Discotienda discotienda;

	
	public Persistencia(Discotienda discotienda) {
		super();
		this.discotienda = discotienda;
	}
	
	
	public void cargarDiscotienda() throws FileNotFoundException, IOException{
		File archivo = new File("./data/discotienda.dat");
		if (archivo.exists()) {
			try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(archivo))){
				ArrayList<Disco> discos = (ArrayList<Disco>) ois.readObject();
				discotienda.setDiscos(discos);
			}
		}
	}
	
	public void persistirDiscotienda() throws FileNotFoundException, IOException{
		try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(new File("./data/discotienda.dat")))){
			oos.writeObject(discotienda.getDiscos());
		}
	}
	
}
