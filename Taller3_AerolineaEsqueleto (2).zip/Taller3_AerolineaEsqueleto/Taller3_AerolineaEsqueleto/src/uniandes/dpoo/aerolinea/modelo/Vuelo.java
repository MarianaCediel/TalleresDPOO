package uniandes.dpoo.aerolinea.modelo;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Random;
import uniandes.dpoo.aerolinea.exceptions.VueloSobrevendidoException;
import uniandes.dpoo.aerolinea.modelo.cliente.Cliente;
import uniandes.dpoo.aerolinea.tiquetes.GeneradorTiquetes;
import uniandes.dpoo.aerolinea.tiquetes.Tiquete;

public class Vuelo {
	private String fecha;
	private Ruta ruta;
	private Avion avion;
	private Map<String, Tiquete> tiquetes = new HashMap<>();

	public Vuelo(String fecha, Ruta ruta, Avion avion) {
		this.fecha = fecha;
		this.ruta = ruta;
		this.avion = avion;
	}

	public String getFecha() {
		return fecha;
	}

	public void setFecha(String fecha) {
		this.fecha = fecha;
	}

	public Ruta getRuta() {
		return ruta;
	}

	public void setRuta(Ruta ruta) {
		this.ruta = ruta;
	}

	public Avion getAvion() {
		return avion;
	}

	public void setAvion(Avion avion) {
		this.avion = avion;
	}

	public Collection<Tiquete> getTiquetes() {
		Collection<Tiquete> valores;
		valores = tiquetes.values();
		
		return valores;
	}
	
	public int venderTiquetes(Cliente cliente, CalculadoraTarifas calculadora, int cantidad) throws VueloSobrevendidoException {
        
        Avion avion= this.getAvion();
        List<String> codigosTiquetesAEliminar = new ArrayList<>();

        
        if (cantidad > avion.getCapacidad()) {
            throw new VueloSobrevendidoException(this); 
        }
        
        int costoPorTiquete = calculadora.calcularTarifa(this, cliente);
        int costoTotal = costoPorTiquete * cantidad;

        for (int i = 0; i < cantidad; i++) {
        	
            Tiquete tiquete = GeneradorTiquetes.generarTiquete(this, cliente, cantidad);
            tiquetes.put(tiquete.getCodigo(), tiquete); 
            cliente.agregarTiquete(tiquete); 
            
        }
        
        for (String codigo : codigosTiquetesAEliminar) {
            tiquetes.remove(codigo);
        }
        

        return costoTotal;
    }
	
	
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        Vuelo vuelo = (Vuelo) obj;
        return Objects.equals(fecha, vuelo.fecha) &&
               Objects.equals(avion, vuelo.avion) &&
               Objects.equals(ruta, vuelo.ruta) &&
               Objects.equals(tiquetes, vuelo.tiquetes);
    }
}
