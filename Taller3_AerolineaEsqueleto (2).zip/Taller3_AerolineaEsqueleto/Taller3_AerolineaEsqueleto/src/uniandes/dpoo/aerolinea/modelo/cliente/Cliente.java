package uniandes.dpoo.aerolinea.modelo.cliente;

import java.util.List;
import java.util.ArrayList;
import uniandes.dpoo.aerolinea.modelo.Vuelo;
import uniandes.dpoo.aerolinea.tiquetes.Tiquete;


public abstract class Cliente {
	
	private List<Tiquete> tiquetesUsados = new ArrayList<>();
	private List<Tiquete> tiquetesSinUsar = new ArrayList<>();

	public Cliente() {
	}
	
	public abstract String getTipoCliente();
	
	public abstract String getIdentificador();
	
	public void agregarTiquete(Tiquete tiquete) {
		tiquetesSinUsar.add(tiquete);
	}
	
	public int calcularValorTotalTiquetes() {
	int valor= 0;
	for(Tiquete tiquete : tiquetesSinUsar) {
		if(!tiquete.esUsado()) {
			valor+= tiquete.getTarifa();
		}
	}
	return valor;
	}
	
	public void usarTiquetes(Vuelo vuelo) {
		List<Tiquete> tiquetesUsar = new ArrayList<>();
		for(Tiquete tiquete : tiquetesSinUsar) {
			if(tiquete.getVuelo().equals(vuelo)) {
				tiquete.esUsado();
				tiquetesUsar.add(tiquete);
			}
		}
		tiquetesSinUsar.removeAll(tiquetesUsar);
		tiquetesUsados.addAll(tiquetesUsar);
		
	}
}
